<?php

$con = mysqli_connect('localhost', 'root', '','practise');


$txtEmail = $_POST['email'];
$txtName = $_POST['name'];
$txtReview = $_POST['review'];

	$sql = "INSERT INTO `reviewprofile` (`id`, `email`, `name` , `review`) VALUES ('0', '$txtEmail', '$txtName', '$txtReview')";
	$result = mysqli_query($con, $sql);
	if($result)
{
	echo '<script type ="text/JavaScript">';  
	echo 'alert("Review submitted")';  
	echo '</script>';  

 }
 else{
	echo '<script type ="text/JavaScript">';  
	echo 'alert("Review submission failed")';  
	echo '</script>';  
  
 }
?>